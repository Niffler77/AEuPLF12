﻿namespace OOPVererbung
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var person = new Person();

            var leher = new Lehrer();

            var mitarbeiter = new Mitarbeiter();

            var schüler = new Schüler();

            var azubi = new Azubi();
            


        }
    }
}
